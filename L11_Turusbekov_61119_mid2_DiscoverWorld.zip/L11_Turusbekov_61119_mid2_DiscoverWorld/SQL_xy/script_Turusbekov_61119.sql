-- Создание базы данных
CREATE DATABASE DiscoverWorldDB;

-- Использование базы данных
USE DiscoverWorldDB;

-- Создание таблицы клиентов (Customers)
CREATE TABLE Customers (
    CustomerID INT AUTO_INCREMENT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Email VARCHAR(100),
    Phone VARCHAR(20),
    DateOfBirth DATE,
    PassportNumber VARCHAR(20)
);

-- Создание таблицы сотрудников (Employees)
CREATE TABLE Employees (
    EmployeeID INT AUTO_INCREMENT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Email VARCHAR(100),
    Phone VARCHAR(20),
    Position VARCHAR(50),
    HireDate DATE
);

-- Создание таблицы туров (Tours)
CREATE TABLE Tours (
    TourID INT AUTO_INCREMENT PRIMARY KEY,
    TourName VARCHAR(100),
    Destination VARCHAR(100),
    StartDate DATE,
    EndDate DATE,
    Price DECIMAL(10, 2),
    MaxParticipants INT
);

-- Создание таблицы бронирований (Bookings)
CREATE TABLE Bookings (
    BookingID INT AUTO_INCREMENT PRIMARY KEY,
    CustomerID INT,
    TourID INT,
    BookingDate DATE,
    NumberOfPeople INT,
    TotalCost DECIMAL(10, 2),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (TourID) REFERENCES Tours(TourID)
);

-- Создание таблицы сотрудников, назначенных на туры (EmployeeAssignments)
CREATE TABLE EmployeeAssignments (
    AssignmentID INT AUTO_INCREMENT PRIMARY KEY,
    EmployeeID INT,
    TourID INT,
    AssignmentDate DATE,
    FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID),
    FOREIGN KEY (TourID) REFERENCES Tours(TourID)
);

-- Вставка начальных записей в таблицу клиентов (Customers)
INSERT INTO Customers (FirstName, LastName, Email, Phone, DateOfBirth, PassportNumber)
VALUES
('John', 'Doe', 'john.doe@example.com', '123-456-7890', '1980-01-01', 'A12345678'),
('Jane', 'Smith', 'jane.smith@example.com', '098-765-4321', '1990-02-02', 'B98765432');

-- Вставка начальных записей в таблицу сотрудников (Employees)
INSERT INTO Employees (FirstName, LastName, Email, Phone, Position, HireDate)
VALUES
('Alice', 'Brown', 'alice.brown@example.com', '234-567-8901', 'Tour Guide', '2015-05-01'),
('Bob', 'Johnson', 'bob.johnson@example.com', '345-678-9012', 'Travel Agent', '2017-03-15');

-- Вставка начальных записей в таблицу туров (Tours)
INSERT INTO Tours (TourName, Destination, StartDate, EndDate, Price, MaxParticipants)
VALUES
('European Highlights', 'Europe', '2024-06-01', '2024-06-15', 2500.00, 20),
('African Safari', 'Africa', '2024-07-10', '2024-07-20', 3000.00, 15);

-- Вставка начальных записей в таблицу бронирований (Bookings)
INSERT INTO Bookings (CustomerID, TourID, BookingDate, NumberOfPeople, TotalCost)
VALUES
(1, 1, '2024-01-01', 2, 5000.00),
(2, 2, '2024-02-01', 1, 3000.00);

-- Вставка начальных записей в таблицу назначений сотрудников (EmployeeAssignments)
INSERT INTO EmployeeAssignments (EmployeeID, TourID, AssignmentDate)
VALUES
(1, 1, '2024-05-01'),
(2, 2, '2024-06-01');