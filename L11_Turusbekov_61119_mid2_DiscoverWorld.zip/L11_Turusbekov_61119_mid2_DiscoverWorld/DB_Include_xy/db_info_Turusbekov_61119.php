<?php
$servername = "localhost";
$username = "root";         // Usually 'root' for local development, replace with your DB username
$password = "";             // Usually empty for local development, replace with your DB password
$dbname = "DiscoverWorldDB";  // Correct database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
