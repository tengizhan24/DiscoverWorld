<nav>
    <a href="start_Turusbekov.php">Home</a>
    <a href="see_customers_Turusbekov.php">View Customers</a>
    <a href="see_employees_Turusbekov.php">View Employees</a>
    <a href="see_tours_Turusbekov.php">View Tours</a>
    <a href="see_bookings_Turusbekov.php">View Bookings</a>
    <a href="see_assignments_Turusbekov.php">View Assignments</a>
    <a href="add_customer_Turusbekov.php">Add Customer</a>
    <a href="add_employee_Turusbekov.php">Add Employee</a>
    <a href="add_tour_Turusbekov.php">Add Tour</a>
    <a href="add_booking_Turusbekov.php">Add Booking</a>
    <a href="add_assignment_Turusbekov.php">Add Assignment</a>
</nav>
