<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DiscoverWorld - Turusbekov</title>
    <link rel="stylesheet" href="../CSS_xy/style_Turusbekov_61119.css">
</head>
<body>
<header>
    <h1>DiscoverWorld</h1>
    <p>Tengizkhan Turusbekov ID: 61119</p>
</header>
<?php include 'navigation_Turusbekov_61119.php'; ?>
