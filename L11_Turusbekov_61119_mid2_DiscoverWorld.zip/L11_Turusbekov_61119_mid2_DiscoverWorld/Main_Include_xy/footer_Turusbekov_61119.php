<footer>
    <p>&copy; 2024 DiscoverWorld. Tengizkhan Turusbekov ID: 61119</p>
</footer>
</body>
</html>
