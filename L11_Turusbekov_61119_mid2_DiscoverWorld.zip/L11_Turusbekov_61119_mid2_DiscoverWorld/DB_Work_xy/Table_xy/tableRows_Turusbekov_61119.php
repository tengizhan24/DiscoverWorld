<?php
function generateTableRows($result) {
    $rows = '';
    while($row = $result->fetch_assoc()) {
        $rows .= '<tr>';
        foreach ($row as $value) {
            $rows .= '<td>' . htmlspecialchars($value) . '</td>';
        }
        $rows .= '</tr>';
    }
    return $rows;
}
?>
