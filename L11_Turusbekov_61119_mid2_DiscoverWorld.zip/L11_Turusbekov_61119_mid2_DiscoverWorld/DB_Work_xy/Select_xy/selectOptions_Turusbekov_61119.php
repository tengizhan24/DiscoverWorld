<?php
include '../../DB_Include_xy/db_info_Turusbekov_61119.php';

if (strpos($_SERVER['PHP_SELF'], 'add_booking_Turusbekov.php') !== false) {
    $sql = "SELECT CustomerID, FirstName, LastName FROM Customers";
} elseif (strpos($_SERVER['PHP_SELF'], 'add_assignment_Turusbekov.php') !== false) {
    $sql = "SELECT EmployeeID, FirstName, LastName FROM Employees";
} else {
    $sql = "SELECT TourID, TourName FROM Tours";
}

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        if (strpos($_SERVER['PHP_SELF'], 'add_booking_Turusbekov.php') !== false) {
            echo "<option value='" . $row["CustomerID"] . "'>" . $row["FirstName"] . " " . $row["LastName"] . "</option>";
        } elseif (strpos($_SERVER['PHP_SELF'], 'add_assignment_Turusbekov.php') !== false) {
            echo "<option value='" . $row["EmployeeID"] . "'>" . $row["FirstName"] . " " . $row["LastName"] . "</option>";
        } else {
            echo "<option value='" . $row["TourID"] . "'>" . $row["TourName"] . "</option>";
        }
    }
} else {
    echo "<option value=''>No results found</option>";
}

$conn->close();
?>
