<?php
include '../../DB_Include_xy/db_info_Turusbekov_61119.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $table = '';
    $fields = '';
    $values = '';

    if (isset($_POST['firstname']) && isset($_POST['lastname']) && isset($_POST['email']) && isset($_POST['phone']) && isset($_POST['dob']) && isset($_POST['passportnumber'])) {
        $table = 'Customers';
        $fields = 'FirstName, LastName, Email, Phone, DateOfBirth, PassportNumber';
        $values = "'" . $_POST['firstname'] . "', '" . $_POST['lastname'] . "', '" . $_POST['email'] . "', '" . $_POST['phone'] . "', '" . $_POST['dob'] . "', '" . $_POST['passportnumber'] . "'";
    } elseif (isset($_POST['firstname']) && isset($_POST['lastname']) && isset($_POST['email']) && isset($_POST['phone']) && isset($_POST['position']) && isset($_POST['hiredate'])) {
        $table = 'Employees';
        $fields = 'FirstName, LastName, Email, Phone, Position, HireDate';
        $values = "'" . $_POST['firstname'] . "', '" . $_POST['lastname'] . "', '" . $_POST['email'] . "', '" . $_POST['phone'] . "', '" . $_POST['position'] . "', '" . $_POST['hiredate'] . "'";
    } elseif (isset($_POST['tourname']) && isset($_POST['destination']) && isset($_POST['startdate']) && isset($_POST['enddate']) && isset($_POST['price']) && isset($_POST['maxparticipants'])) {
        $table = 'Tours';
        $fields = 'TourName, Destination, StartDate, EndDate, Price, MaxParticipants';
        $values = "'" . $_POST['tourname'] . "', '" . $_POST['destination'] . "', '" . $_POST['startdate'] . "', '" . $_POST['enddate'] . "', '" . $_POST['price'] . "', '" . $_POST['maxparticipants'] . "'";
    } elseif (isset($_POST['customerid']) && isset($_POST['tourid']) && isset($_POST['bookingdate']) && isset($_POST['numberofpeople']) && isset($_POST['totalcost'])) {
        $table = 'Bookings';
        $fields = 'CustomerID, TourID, BookingDate, NumberOfPeople, TotalCost';
        $values = "'" . $_POST['customerid'] . "', '" . $_POST['tourid'] . "', '" . $_POST['bookingdate'] . "', '" . $_POST['numberofpeople'] . "', '" . $_POST['totalcost'] . "'";
    } elseif (isset($_POST['employeeid']) && isset($_POST['tourid']) && isset($_POST['assignmentdate'])) {
        $table = 'EmployeeAssignments';
        $fields = 'EmployeeID, TourID, AssignmentDate';
        $values = "'" . $_POST['employeeid'] . "', '" . $_POST['tourid'] . "', '" . $_POST['assignmentdate'] . "'";
    }

    if ($table != '' && $fields != '' && $values != '') {
        $sql = "INSERT INTO $table ($fields) VALUES ($values)";
        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Invalid form data";
    }
}

$conn->close();
?>
