<?php
include '../Main_Include_xy/header_Turusbekov_61119.php';
include '../DB_Include_xy/db_info_Turusbekov_61119.php';

$sql = "SELECT * FROM Tours";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>Tour Name</th><th>Destination</th><th>Start Date</th><th>End Date</th><th>Price</th><th>Max Participants</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["TourID"] . "</td><td>" . $row["TourName"] . "</td><td>" . $row["Destination"] . "</td><td>" . $row["StartDate"] . "</td><td>" . $row["EndDate"] . "</td><td>" . $row["Price"] . "</td><td>" . $row["MaxParticipants"] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
include '../Main_Include_xy/footer_Turusbekov_61119.php';
?>
