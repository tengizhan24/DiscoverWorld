<?php
include '../Main_Include_xy/header_Turusbekov_61119.php';
include '../DB_Include_xy/db_info_Turusbekov_61119.php';

$sql = "SELECT * FROM Employees";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Email</th><th>Phone</th><th>Position</th><th>Hire Date</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["EmployeeID"] . "</td><td>" . $row["FirstName"] . "</td><td>" . $row["LastName"] . "</td><td>" . $row["Email"] . "</td><td>" . $row["Phone"] . "</td><td>" . $row["Position"] . "</td><td>" . $row["HireDate"] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
include '../Main_Include_xy/footer_Turusbekov_61119.php';
?>
