<?php
include '../Main_Include_xy/header_Turusbekov_61119.php';
include '../DB_Include_xy/db_info_Turusbekov_61119.php';

$sql = "SELECT Bookings.BookingID, Customers.FirstName, Customers.LastName, Tours.TourName, Bookings.BookingDate, Bookings.NumberOfPeople, Bookings.TotalCost 
        FROM Bookings 
        JOIN Customers ON Bookings.CustomerID = Customers.CustomerID 
        JOIN Tours ON Bookings.TourID = Tours.TourID";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>Customer</th><th>Tour</th><th>Booking Date</th><th>Number of People</th><th>Total Cost</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["BookingID"] . "</td><td>" . $row["FirstName"] . " " . $row["LastName"] . "</td><td>" . $row["TourName"] . "</td><td>" . $row["BookingDate"] . "</td><td>" . $row["NumberOfPeople"] . "</td><td>" . $row["TotalCost"] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
include '../Main_Include_xy/footer_Turusbekov_61119.php';
?>
