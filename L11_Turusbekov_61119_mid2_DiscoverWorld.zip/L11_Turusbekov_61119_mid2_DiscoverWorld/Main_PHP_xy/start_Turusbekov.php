<?php include '../Main_Include_xy/header_Turusbekov_61119.php'; ?>
<main>
    <img src="../IMG/img1.jpg" alt="DiscoverWorld">
</main>
<?php include '../Main_Include_xy/footer_Turusbekov_61119.php'; ?>
