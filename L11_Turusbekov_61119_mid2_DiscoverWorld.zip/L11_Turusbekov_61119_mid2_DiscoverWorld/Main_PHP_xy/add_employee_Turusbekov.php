<?php include '../Main_Include_xy/header_Turusbekov_61119.php'; ?>
<main>
    <h2>Add Employee</h2>
    <form action="../DB_Work_xy/Add_xy/checkAdd_Turusbekov_61119.php" method="post">
        <label for="firstname61119">First Name:</label>
        <input type="text" id="firstname61119" name="firstname"><br>
        <label for="lastname61119">Last Name:</label>
        <input type="text" id="lastname61119" name="lastname"><br>
        <label for="email61119">Email:</label>
        <input type="text" id="email61119" name="email"><br>
        <label for="phone61119">Phone:</label>
        <input type="text" id="phone61119" name="phone"><br>
        <label for="position61119">Position:</label>
        <input type="text" id="position61119" name="position"><br>
        <label for="hiredate61119">Hire Date:</label>
        <input type="date" id="hiredate61119" name="hiredate"><br>
        <input type="submit" value="Add Employee">
    </form>
</main>
<?php include '../Main_Include_xy/footer_Turusbekov_61119.php'; ?>
