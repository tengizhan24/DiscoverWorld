<?php include '../Main_Include_xy/header_Turusbekov_61119.php'; ?>
<main>
    <h2>Add Tour</h2>
    <form action="../DB_Work_xy/Add_xy/checkAdd_Turusbekov_61119.php" method="post">
        <label for="tourname61119">Tour Name:</label>
        <input type="text" id="tourname61119" name="tourname"><br>
        <label for="destination61119">Destination:</label>
        <input type="text" id="destination61119" name="destination"><br>
        <label for="startdate61119">Start Date:</label>
        <input type="date" id="startdate61119" name="startdate"><br>
        <label for="enddate61119">End Date:</label>
        <input type="date" id="enddate61119" name="enddate"><br>
        <label for="price61119">Price:</label>
        <input type="text" id="price61119" name="price"><br>
        <label for="maxparticipants61119">Max Participants:</label>
        <input type="number" id="maxparticipants61119" name="maxparticipants"><br>
        <input type="submit" value="Add Tour">
    </form>
</main>

<?php include '../Main_Include_xy/footer_Turusbekov_61119.php'; ?>
