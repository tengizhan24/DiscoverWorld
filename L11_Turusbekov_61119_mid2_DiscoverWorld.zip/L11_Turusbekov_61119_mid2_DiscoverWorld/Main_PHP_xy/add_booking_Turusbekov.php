<?php
include '../Main_Include_xy/header_Turusbekov_61119.php';
include '../DB_Include_xy/db_info_Turusbekov_61119.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customerid = $_POST['customerid'];
    $tourid = $_POST['tourid'];
    $bookingdate = $_POST['bookingdate'];
    $numberofpeople = $_POST['numberofpeople'];
    $totalcost = $_POST['totalcost'];

    $sql = "INSERT INTO Bookings (CustomerID, TourID, BookingDate, NumberOfPeople, TotalCost) 
            VALUES ('$customerid', '$tourid', '$bookingdate', '$numberofpeople', '$totalcost')";

    if ($conn->query($sql) === TRUE) {
        echo "New booking created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<main>
    <h2>Add Booking</h2>
    <form action="add_booking_Turusbekov.php" method="post">
        <label for="customerid61119">Customer:</label>
        <select id="customerid61119" name="customerid" required>
            <?php
            $sql = "SELECT CustomerID, FirstName, LastName FROM Customers";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['CustomerID'] . "'>" . $row['FirstName'] . " " . $row['LastName'] . "</option>";
                }
            } else {
                echo "<option value=''>No customers found</option>";
            }
            ?>
        </select><br>

        <label for="tourid61119">Tour:</label>
        <select id="tourid61119" name="tourid" required>
            <?php
            $sql = "SELECT TourID, TourName FROM Tours";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['TourID'] . "'>" . $row['TourName'] . "</option>";
                }
            } else {
                echo "<option value=''>No tours found</option>";
            }
            ?>
        </select><br>

        <label for="bookingdate61119">Booking Date:</label>
        <input type="date" id="bookingdate61119" name="bookingdate" required><br>

        <label for="numberofpeople61119">Number of People:</label>
        <input type="number" id="numberofpeople61119" name="numberofpeople" required><br>

        <label for="totalcost61119">Total Cost:</label>
        <input type="number" step="0.01" id="totalcost61119" name="totalcost" required><br>

        <input type="submit" value="Add Booking">
    </form>
</main>

<?php include '../Main_Include_xy/footer_Turusbekov_61119.php'; ?>
