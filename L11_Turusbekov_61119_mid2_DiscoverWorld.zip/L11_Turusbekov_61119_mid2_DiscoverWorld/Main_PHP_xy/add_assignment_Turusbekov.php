<?php
include '../Main_Include_xy/header_Turusbekov_61119.php';
include '../DB_Include_xy/db_info_Turusbekov_61119.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $employeeid = $_POST['employeeid'];
    $tourid = $_POST['tourid'];
    $assignmentdate = $_POST['assignmentdate'];

    $sql = "INSERT INTO EmployeeAssignments (EmployeeID, TourID, AssignmentDate) 
            VALUES ('$employeeid', '$tourid', '$assignmentdate')";

    if ($conn->query($sql) === TRUE) {
        echo "New assignment created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<main>
    <h2>Add Assignment</h2>
    <form action="add_assignment_Turusbekov.php" method="post">
        <label for="employeeid61119">Employee:</label>
        <select id="employeeid61119" name="employeeid" required>
            <?php
            $sql = "SELECT EmployeeID, FirstName, LastName FROM Employees";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['EmployeeID'] . "'>" . $row['FirstName'] . " " . $row['LastName'] . "</option>";
                }
            } else {
                echo "<option value=''>No employees found</option>";
            }
            ?>
        </select><br>

        <label for="tourid61119">Tour:</label>
        <select id="tourid61119" name="tourid" required>
            <?php
            $sql = "SELECT TourID, TourName FROM Tours";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['TourID'] . "'>" . $row['TourName'] . "</option>";
                }
            } else {
                echo "<option value=''>No tours found</option>";
            }
            ?>
        </select><br>

        <label for="assignmentdate61119">Assignment Date:</label>
        <input type="date" id="assignmentdate61119" name="assignmentdate" required><br>

        <input type="submit" value="Add Assignment">
    </form>
</main>

<?php include '../Main_Include_xy/footer_Turusbekov_61119.php'; ?>
