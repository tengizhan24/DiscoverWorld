<?php
include '../Main_Include_xy/header_Turusbekov_61119.php';
include '../DB_Include_xy/db_info_Turusbekov_61119.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $dateofbirth = $_POST['dateofbirth'];
    $passportnumber = $_POST['passportnumber'];

    $sql = "INSERT INTO Customers (FirstName, LastName, Email, Phone, DateOfBirth, PassportNumber) 
            VALUES ('$firstname', '$lastname', '$email', '$phone', '$dateofbirth', '$passportnumber')";

    if ($conn->query($sql) === TRUE) {
        echo "New customer created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Customer - DiscoverWorld</title>
    <link rel="stylesheet" href="../CSS_xy/style_Turusbekov_61119.css">
</head>
<body>
    <main>
        <h2>Add Customer</h2>
        <form action="add_customer_Turusbekov.php" method="post">
            <label for="firstname61119">First Name:</label>
            <input type="text" id="firstname61119" name="firstname" required>
            
            <label for="lastname61119">Last Name:</label>
            <input type="text" id="lastname61119" name="lastname" required>
            
            <label for="email61119">Email:</label>
            <input type="email" id="email61119" name="email" required>
            
            <label for="phone61119">Phone:</label>
            <input type="tel" id="phone61119" name="phone" required>
            
            <label for="dateofbirth61119">Date of Birth:</label>
            <input type="date" id="dateofbirth61119" name="dateofbirth" required>
            
            <label for="passportnumber61119">Passport Number:</label>
            <input type="text" id="passportnumber61119" name="passportnumber" required>
            
            <input type="submit" value="Add Customer">
        </form>
    </main>
</body>
</html>
<?php include '../Main_Include_xy/footer_Turusbekov_61119.php'; ?>

