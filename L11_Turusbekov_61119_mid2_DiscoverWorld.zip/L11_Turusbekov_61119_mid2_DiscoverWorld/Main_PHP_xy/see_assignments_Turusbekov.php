<?php
include '../Main_Include_xy/header_Turusbekov_61119.php';
include '../DB_Include_xy/db_info_Turusbekov_61119.php';

$sql = "SELECT EmployeeAssignments.AssignmentID, Employees.FirstName, Employees.LastName, Tours.TourName, EmployeeAssignments.AssignmentDate 
        FROM EmployeeAssignments 
        JOIN Employees ON EmployeeAssignments.EmployeeID = Employees.EmployeeID 
        JOIN Tours ON EmployeeAssignments.TourID = Tours.TourID";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>Employee</th><th>Tour</th><th>Assignment Date</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["AssignmentID"] . "</td><td>" . $row["FirstName"] . " " . $row["LastName"] . "</td><td>" . $row["TourName"] . "</td><td>" . $row["AssignmentDate"] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
include '../Main_Include_xy/footer_Turusbekov_61119.php';
?>
